"user client"

const LoaderCircle = () => {
  return (
    <div className=" relative border-[2px] border-transparent border-l-white  h-[15px] w-[15px] rounded-full animate-spin">
    </div>
  )
}

export default LoaderCircle
