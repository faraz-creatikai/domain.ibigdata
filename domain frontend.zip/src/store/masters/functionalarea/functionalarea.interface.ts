export interface functionalareaAllDataInterface {
    Name:string,
    Status:string
}

export interface functionalareaGetDataInterface {
    _id: string;
    Name:string,
    Status:string
}

export interface functionalareaDialogDataInterface {
    id: string;
    Name:string,
    Status:string
  }