export interface expensesAllDataInterface {
    Name:string;
    Status:string;
}

export interface expensesGetDataInterface {
    _id: string;
    Name:string;
    Status:string;
}

export interface expensesDialogDataInterface {
    id: string;
    Name:string;
    Status:string;
  }