export interface builderslidersAllDataInterface {
    Image:File;
    Status:string;
}

export interface builderslidersGetDataInterface {
    _id: string;
    Image:string;
    Status:string;
}

export interface DeleteDialogDataInterface {
    id: string;
  }