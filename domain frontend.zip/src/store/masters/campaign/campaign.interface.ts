export interface campaignAllDataInterface {
    Name:string;
    Status:string;
}

export interface campaignGetDataInterface {
    _id: string;
    Name:string;
    Status:string;
}

export interface DeleteDialogDataInterface {
    id: string;
    Name:string;
    Status:string;
  }