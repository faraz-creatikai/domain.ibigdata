export interface cityAllDataInterface {
    Name:string,
    Status:string
}

export interface cityGetDataInterface {
    _id: string;
    Name:string,
    Status:string
}

export interface cityDialogDataInterface {
    id: string;
    Name:string,
    Status:string
  }