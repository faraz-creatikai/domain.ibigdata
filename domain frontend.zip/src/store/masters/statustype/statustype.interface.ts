export interface statustypeAllDataInterface {
    Name:string;
    Status:string;
}

export interface statustypeGetDataInterface {
    _id: string;
    Name:string;
    Status:string;
}

export interface statustypeDialogDataInterface {
    id: string;
    Name:string;
    Status:string;
  }