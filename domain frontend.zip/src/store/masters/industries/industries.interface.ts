export interface industriesAllDataInterface {
    Name:string,
    Status:string
}

export interface industriesGetDataInterface {
    _id: string;
    Name:string,
    Status:string
}

export interface industriesDialogDataInterface {
    id: string;
    Name:string,
    Status:string
  }