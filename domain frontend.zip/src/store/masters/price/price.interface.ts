export interface priceAllDataInterface {
    Name:string;
    Status:string;
}

export interface priceGetDataInterface {
    _id: string;
    Name:string;
    Status:string;
}

export interface priceDialogDataInterface {
    id: string;
    Name:string;
    Status:string;
  }