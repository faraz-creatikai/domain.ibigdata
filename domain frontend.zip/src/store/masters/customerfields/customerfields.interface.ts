export interface customerFieldsAllDataInterface {
    Name:string;
    Status:string;
}

export interface customerFieldsGetDataInterface {
    _id: string;
    Name:string;
    Status:string;
}

export interface customerFieldsDialogDataInterface {
    id: string;
    Name:string;
    Status:string;
  }