export interface contactstatustypeAllDataInterface {
    Name:string;
    Status:string;
}

export interface contactstatustypeGetDataInterface {
    _id: string;
    Name:string;
    Status:string;
}

export interface contactstatustypeDialogDataInterface {
    id: string;
    Name:string;
    Status:string;
  }