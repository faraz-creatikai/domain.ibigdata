export interface facilitiesAllDataInterface {
    Name:string,
    Status:string
}

export interface facilitiesGetDataInterface {
    _id: string;
    Name:string,
    Status:string
}

export interface facilitiesDialogDataInterface {
    id: string;
    Name:string,
    Status:string
  }