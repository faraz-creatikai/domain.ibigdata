export interface requestUserAllDataInterface{
    email:string;
    name:string;
    password:string;
    phone:string;
}

export interface requestUserGetDataInterface{
    email:string;
    name:string;
    phone?:string;
}

