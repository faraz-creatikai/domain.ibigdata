export interface usersAllDataInterface {
    email: string;
    fullname: string;
    password:string;
}

export interface usersGetDataInterface {
  
}

export interface usersAdvInterface {
   
  }

export interface DeleteDialogDataInterface {
    id: string;
    usersName: string;
    usersEmail: string;
  }