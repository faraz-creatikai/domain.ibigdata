export interface customerFieldsAllDataInterface {
    fieldKey:string;
    displayLabel:string;
}

export interface customerFieldsGetDataInterface {
    id: string;
    fieldKey:string;
    displayLabels:string;
}


